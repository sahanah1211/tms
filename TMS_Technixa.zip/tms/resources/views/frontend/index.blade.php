<!DOCTYPE html>
<html>
<head>
    <title>Search Thesis</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet"
          href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
</head>
<style>
    body{
    background-color:#f8f9fc;

}
</style>
<body>

        <div class="col-md-10">
            <table class="table">
                <thead>
                <tr>
                    <th>No</th>
                    <th>Student ID</th>
                    <th>Thesis Title</th>
                    <th>Download/View</th>
                </tr>
                </thead>
                @if($theses)
                    <tbody>
                    @php($count = 0)
                    @foreach($theses as $thesis)
                        @foreach($thesis->thesisSubmission as $sub)
                            <tr>
                                <td>
                                    {{$count += 1}}
                                </td>
                                <td>
                                    {{$sub->getUser()->key}}
                                </td>
                                <td>
                                    {{$thesis->title}}
                                </td>
                                <td>
                                    <a href="{{route('user.download',$sub->id)}}" class="btn btn-success" style="font-size: 14px;"><i class="fa fa-download"></i> Download </a>
                                </td>
                            </tr>
                        @endforeach
                    @endforeach
                    </tbody>
                @endif
            </table>
        </div>
    </div>
</div>
</body>
</html>
