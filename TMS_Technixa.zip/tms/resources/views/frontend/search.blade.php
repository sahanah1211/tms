@extends('layouts.app')

@section('content')
    Hello
@endsection
