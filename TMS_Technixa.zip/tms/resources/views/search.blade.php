<!DOCTYPE html>
<html>
<head>
<title>Search Thesis</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet"
	href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
</head>
<style>
body{
	background-color:red;
}
</style>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <form action="">
                <h2>Search Thesis</h2>
                <div class="form-group">
                    <input type="text" name="q" placeholder="Search for thesis" class="form-control"/>
                    <input type="submit" class="btn btn-primary" value="Search"/>
                </div>
            </form>
			<p> The Search results for your query <b> {{ $q  }} </b> are :</p>
        </div>
        <div class="col-md-10">
            <table class="table">
			<thead>
				<tr>
					<th>No</th>
					<th>Student ID</th>
					<th>Thesis Title</th>
					<th>Download/View</th>
				</tr>
			</thead>
				<tbody>
				@php($count = 0)
					@foreach($theses as $thesis)	
					<tr>
						<td>
							@if (($thesis->thesis->title) == ( $q  ) || ($q ) == ( "" ))
							{{$count += 1}}
							@endif
						</td>
						<td>
							@if (($thesis->thesis->title) == ( $q  ) || ($q ) == ( "" ))
							{{$thesis->user->key}}
							@endif
						</td>
						<td>
							@if (($thesis->thesis->title) == ( $q  ) || ($q ) == ( "" ))
							{{$thesis->thesis->title}}
							@endif
						</td>
						<td>
							@if (($thesis->thesis->title) == ( $q  ) || ($q ) == ( "" ))
							<a href="{{route('admin.thesis.download',$thesis->id)}}" class="btn btn-success" style="font-size: 14px;"><i class="fa fa-download"></i> Download </a>
							@endif		
						</td>
                    </tr>
					@endforeach
				</tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>
