@extends('layouts.student.student')

@section('content')
    <div class="card-header">
        @if (Session::has('message'))
            <div class="alert alert-info">{{ Session::get('message') }}</div>
        @endif
    </div>
    <!------- Submission ------>
    <div class="small-container mt-1">
        <div class="row">
            <table>
                <tr>
                    <th>No.</th>
                    <th style="width: 190px;">Submission Due Date</th>
                    <th>Title</th>
                    <th>Remarks</th>
                    <th>Status</th>
                </tr>
            </table>
        </div>
        <div class="row pre-scrollable" style="max-height: 60vh;">
            <table>
                @php($count = 0)
                @foreach($theses as $thesis)
                    <tr>
                        <td>{{$count += 1}}</td>
                        <td style="width: 190px;">{{$thesis->thesis->submission_date}}</td>
                        <td>
                            {{$thesis->thesis->title}}
                        </td>
                        <td>
                            @if($thesis->submission)
                                {{$thesis->submission->remark}}
                            @else
                                You haven't uploaded any document
                            @endif
                        </td>
                        <td>
                            @if($thesis->submission)
                                @if($thesis->submission->correction == 3)
                                    <a href="{{$thesis->submission->file}}" class="btn btn-success"
                                    >
                                        <i class="fa fa-download"></i>
                                        Download
                                    </a>
                                @else
                                    <div class="btn btn-info"> <span>OnGoing</span> </div>
                                @endif
                            @else
                                <div class="btn btn-info"> <span>OnGoing</span> </div>
                            @endif
                        </td>
                    </tr>
                @endforeach
            </table>
        </div>
    </div>
@endsection
