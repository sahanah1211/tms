



	



	<div class="container h-100">
      <div class="d-flex justify-content-center h-100">
        <div class="searchbar">
		<form name="" method="post" enctype="multipart/form-data">

		  <input class="search_input" type="text" name="searchdata" required="true" placeholder="Search By Name or Title...">
		  <button class="search_icon" type="submit" name="search"><i class="fas fa-search"></i></button>

        </div>
      </div>
    </div>


	<?php
if(isset($_POST['search']))
{ 

$sdata=$_POST['searchdata'];
  ?>
  <h4 align="center">Result against "<?php echo $sdata;?>" name </h4>

                                        <table  class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th> Name</th>
                                                    
                                                </tr>
                                            </thead>
                                            <tbody>   
                                                <?php
                                               if (isset($_GET['page_no']) && $_GET['page_no']!="") {
  $page_no = $_GET['page_no'];
  } else {
    $page_no = 1;
        }
        // Formula for pagination
        $no_of_records_per_page = 5;
        $offset = ($page_no-1) * $no_of_records_per_page;
        $previous_page = $page_no - 1;
  $next_page = $page_no + 1;
  $adjacents = "2"; 
$ret = "SELECT id FROM thesis_submissions";
$query1 = $dbh -> prepare($ret);
$query1->execute();
$results1=$query1->fetchAll(PDO::FETCH_OBJ);
$total_rows=$query1->rowCount();
$total_no_of_pages = ceil($total_rows / $no_of_records_per_page);
  $second_last = $total_no_of_pages - 1; // total page minus 1
                                               
  $sql="SELECT thesis_submissions.student_id,thesis_submissions.file,
  thesis_submissions.mark,users.id as uid, users.name

    join users
    on thesis_submissions.student_id=users.id  where  tbladdthesis.id like '$sdata%'|| thesis_submissions.thesis_id like '$sdata%' 
    || users.name like  '$sdata%'";













$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);

$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $row)
{               ?>
   
                                                <tr>
                                                    <td><?php  echo htmlentities($row->name);?></td>

                    
                                        
<?php } ?> 
                                                    <td><a href="view-thesis-details.php?assinid=<?php echo htmlentities ($row->assinid);?> && uid=<?php echo htmlentities ($row->uid);?> ">View</a></td>
                                                </tr>
                                             <?php 
$cnt=$cnt+1;
} } else { ?>
  <tr>
    <td colspan="9"> No record found </td>

  </tr>
                                            </tbody>
                                            
 
                                        </table>
                                        
				

