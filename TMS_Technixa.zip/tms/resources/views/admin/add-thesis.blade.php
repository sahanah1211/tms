@extends('layouts.admin.admin')

@section('content')
    <div class="card-header">
        <span>Admin home</span>
    </div>
@endsection
