@extends('layouts.admin.admin')

@section('content')
    <div class="card-header">
        <span>Admin home</span>
    </div>

    <!------- Submission ------>
    <div class="small-container mt-1">
        <div class="row">
            <table>
                <tr>
                    <th>No.</th>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Remarks</th>
                    <th>Files</th>
                </tr>
            </table>
        </div>
        <div class="row pre-scrollable" style="max-height: 60vh;">
            <table>
                @php($count = 0)
                @foreach($theses as $thesis)
                    <tr>
                        <td>{{$count += 1}}</td>
                        <td>{{$thesis->user->key}}</td>
                        <td>{{$thesis->user->name}}</td>
                        <td> @if($thesis->remark) {{$thesis->remark}}@else No Remark found @endif </td>
                        <td>
                            <a href="{{route('admin.thesis.download',$thesis->id)}}" class="btn btn-success"><i class="fa fa-download"></i> Download</a>
                        </td>
                    </tr>
                @endforeach
            </table>
        </div>
    </div>
@endsection
