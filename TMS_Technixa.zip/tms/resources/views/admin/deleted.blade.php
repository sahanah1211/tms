@extends('layouts.admin.admin')

@section('content')
    <div class="modal-title">
        <h4>List of Thesis</h4>
    </div>
    <!------- Submission final ------>
    <div class="small-container mt-1">
        <div class="row">
            <table>
                <tr>
                    <th>No.</th>
                    <th>Student ID</th>
                    <th>Mark</th>
                    <th>Title</th>
                    <th>Files</th>
                </tr>
            </table>
        </div>
        <div class="row pre-scrollable" style="max-height: 60vh;">
            <table>
                @php($count = 0)
                @foreach($theses as $thesis)
                    <tr>
                        <td>{{$count += 1}}</td>
                        <td>{{$thesis->user->key}}</td>
                        <td>
                            {{$thesis->mark}}
                        </td>
                        <td>
                            {{$thesis->thesis->title}}
                        </td>
                        <td>
                            <a href="{{route('admin.thesis.delete',$thesis->id)}}" class="btn btn-success" style="font-size: 14px;"><i class="fa fa-delete"></i> Delete</a>
                        </td>
                    </tr>
                @endforeach
            </table>
        </div>
    </div>
@endsection