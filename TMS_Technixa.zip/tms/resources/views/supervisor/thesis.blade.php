@extends('layouts.supervisor.supervisor')

@section('content')
    <div class="card-header">
        <span> Supervisor Home </span>
    </div>

@endsection
