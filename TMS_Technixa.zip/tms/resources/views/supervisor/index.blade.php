@extends('layouts.supervisor.supervisor')

@section('content')
    <div class="card-header">
        <span> Supervisor Home </span>
        @if (Session::has('message'))
            <div class="alert alert-info">{{ Session::get('message') }}</div>
        @endif
    </div>
    <!------- Submission ------>
    <div class="small-container mt-1">
        <div class="row">
            <table>
                <tr>
                    <th>No.</th>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Title</th>
                    <th>Action</th>
                </tr>
            </table>
        </div>
        <div class="row pre-scrollable" style="max-height: 60vh;">
            <table>
                @php($count = 0)
                @foreach($theses as $thesis)
                    <tr>
                        <td>{{$count += 1}}</td>
                        <td>{{$thesis->user->key}}</td>
                        <td>
                            {{$thesis->user->name}}
                        </td>
                        <td>
                            {{$thesis->thesis->title}}
                        </td>
                        <td>
                            <a class="btn btn-success supervisor-assign" href="#"
                                data-toggle="modal" data-target="#SupervisorModal"
                                onclick="event.preventDefault()
                                        document.getElementById('supervisor-thesis-id').value={{$thesis->id}};
                                        "
                            >
                                Examiner
                            </a>
                        </td>
                    </tr>
                @endforeach
            </table>
        </div>    
    </div>

    <!-- Supervisor Modal-->
    <div class="modal fade" id="SupervisorModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Assign Examiner</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form method="post" action="{{route('supervisor')}}">
                    @csrf
                <div class="modal-body">

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <label class="input-group-text" for="inputGroupSelect01">Examiners</label>
                        </div>
                        <input type="hidden" name="supervisor_thesis" id="supervisor-thesis-id" value=""/>
                        <select class="custom-select" id="inputGroupSelect01" name="examiner">
                            @foreach($examiners as $examiner)
                            <option value="{{$examiner->id}}">{{$examiner->name}} </option>
                            @endforeach
                        </select>

                    </div>
                </div>

                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" >Assign</button>
                </div>
                </form>
            </div>
        </div>
    </div>
@endsection
