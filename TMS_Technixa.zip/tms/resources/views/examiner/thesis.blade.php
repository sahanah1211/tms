@extends('layouts.examiner.examiner')

@section('content')
    <div class="card-header">
        <span> All Thesis </span>
        @if (Session::has('message'))
            <div class="alert alert-info">{{ Session::get('message') }}</div>
        @endif
    </div>

    <!------- Submission ------>
    <div class="small-container mt-1">
        <div class="row">
            <table>
                <tr>
                    <th>No.</th>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Title</th>
                    <th>Status</th>
                </tr>
            </table>
        </div>
        <div class="row pre-scrollable" style="max-height: 60vh;">
            <table>
                @php($count = 0)
                @foreach($theses as $thesis)
                    <tr>
                        <td>{{$count += 1}}</td>
                        <td>{{$thesis->user->key}}</td>
                        <td>
                            {{$thesis->user->name}}
                        </td>
                        <td>
                            {{$thesis->thesis->title}}
                        </td>
                        <td>
                            @if($thesis->thesis->completed)
                            <a class="btn btn-success w-100" style="font-size: 14px;" href="{{route('examiner.download',$thesis->id)}}"
                            >
                                <i class="fa fa-download"></i> Completed</a>
                            @else
                                <div class="btn btn-info w-100"> <span>OnGoing</span></div>
                            @endif
                        </td>
                    </tr>
                @endforeach
            </table>
        </div>
    </div>
@endsection
