@extends('layouts.examiner.examiner')

@section('content')

    <div class="card-header">
        <span> Examiner Home </span>
        @if (Session::has('message'))
            <div class="alert alert-info">{{ Session::get('message') }}</div>
        @endif
    </div>

    <!------- Submission ------>
    <div class="small-container mt-1">
        <div class="row">
            <table>
                <tr>
                    <th>No.</th>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Title</th>
                    <th>Actions</th>
                </tr>
            </table>
        </div>
        <div class="row pre-scrollable" style="max-height: 60vh;">
            <table>
                @php($count = 0)
                @foreach($theses as $thesis)
                    @if(!$thesis->thesis->completed)
                        <tr>
                            <td>{{$count += 1}}</td>
                            <td>{{$thesis->user->key}}</td>
                            <td>
                                {{$thesis->user->name}}
                            </td>
                            <td>
                                {{$thesis->thesis->title}}
                            </td>
                            <td>
                                <a class="btn btn-success supervisor-assign w-100" href="#"
                                   data-toggle="modal" data-target="#ExaminerModal"
                                   onclick="event.preventDefault()
                                       document.getElementById('supervisor-thesis-id').value={{$thesis->id}};
                                       "
                                >
                                    <i class="fa fa-edit"></i> Mark</a>

                                <a href="{{route('examiner.download',$thesis->examiner->id)}}" class="btn btn-info w-100" ><i class="fa fa-download"></i> Download</a>
                            </td>
                        </tr>
                    @endif
                @endforeach
            </table>
        </div>
    </div>

    <!-- Examiner Modal-->
    <div class="modal fade" id="ExaminerModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Mark Thesis</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form method="post" action="{{route('examiner')}}">
                    @csrf
                    <div class="modal-body">
                            <input type="hidden" name="thesis" id="supervisor-thesis-id" value=""/>

                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">Mark</span>
                                </div>
                                <input type="number" class="form-control" name="mark" placeholder="Mark" aria-label="Mark" maxlength="1"   required aria-describedby="basic-addon1">
                            </div>

                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">Remark</span>
                                </div>
                                <textarea type="text" class="form-control" name="remark"  style="height: 100px;"  aria-label="Remark" aria-describedby="basic-addon1" autofocus>

                                </textarea>
                            </div>
                    </div>

                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Complete Marking</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

@endsection
