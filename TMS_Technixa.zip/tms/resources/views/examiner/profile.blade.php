@extends('layouts.examiner.examiner')

@section('content')
    @if (Session::has('message'))
        <div class="alert alert-info">{{ Session::get('message') }}</div>
    @endif
    <div class="h-75 w-50 ml-auto mr-auto">
        <div class="card text-muted bg-white mb-3">

            <form action="{{route('examiner.profile.update')}}" method="post" >
                @csrf
                <div class="card-body">
                    <h3 class="text-center mb-1">{{$user->name}}</h3>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="inputGroup-sizing-default">Name</span>
                        </div>
                        <input type="text" class="form-control " aria-label="Default" name="name"
                               aria-describedby="inputGroup-sizing-default" value="{{$user->name}}">
                    </div>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="inputGroup-sizing-default">Phone</span>
                        </div>
                        <input type="text" maxlength="8" minlength="8" class="form-control " aria-label="Default" name="phone"
                               aria-describedby="inputGroup-sizing-default" value="{{$user->phone}}"> 
                    </div>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="inputGroup-sizing-default">Current Password</span>
                        </div>
                        <input type="password" maxlength="8" minlength="8" class="form-control " aria-label="Default" name="c_password"
                               aria-describedby="inputGroup-sizing-default">
                    </div>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="inputGroup-sizing-default">Update Password</span>
                        </div>
                        <input type="password" maxlength="8" minlength="8" class="form-control " aria-label="Default"
                               name="u_password"
                               aria-describedby="inputGroup-sizing-default">
                    </div>

                    <h6 class="card-text">Account Created : {{ $user->created_at->diffForHumans()}}</h6>
                    <h6 class="card-text">Last Updated : {{$user->updated_at->diffForHumans()}}</h6>
                </div>

                <div class="d-flex flex-row w-100">
                    <button type="submit" class="btn text-white bg-success w-50" style="border-radius: 0">Update</button>
                    <form action="" method="post">
                        @csrf
                        <a href="#" type="button" class="btn text-white bg-dark w-50" style="border-radius: 0">Deactivate Account</a>
                    </form>
                </div>
            </form>
        </div>
    </div>

@endsection
