<?php $__env->startSection('content'); ?>
    <div class="card-header">
        <span> Student Home </span>
        <?php if(Session::has('message')): ?>
            <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>
    </div>

    <!------- Submission ------>
    <div class="small-container mt-1">
        <div class="row">
            <table>
                <tr>
                    <th>No.</th>
                    <th style="width: 190px;">Submission Due Date</th>
                    <th>Title</th>
                    <th>Remarks</th>
                    <th>Actions</th>
                </tr>
            </table>
        </div>
        <div class="row pre-scrollable" style="max-height: 60vh;">
            <table>
                <?php ($count = 0); ?>
                <?php $__currentLoopData = $theses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thesis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($count += 1); ?></td>
                        <td style="width: 190px;" ><?php echo e($thesis->thesis->submission_date); ?></td>
                        <td>
                            <?php echo e($thesis->thesis->title); ?>

                        </td>
                        <td>
                            <?php if($thesis->submission): ?>
                                <?php if($thesis->submission->remark): ?>
                                    <?php echo e($thesis->submission->remark); ?>

                                <?php else: ?>
                                    Your documentation is being submitted for reviewing
                                <?php endif; ?>
                            <?php else: ?>
                                You haven't uploaded any document
                            <?php endif; ?>

                        </td>
                        <td >
                            <a class="btn btn-success supervisor-assign w-100" href="#"
                               data-toggle="modal" data-target="#ExaminerModal"
                               onclick="event.preventDefault()
                                   document.getElementById('supervisor-thesis-id').value=<?php echo e($thesis->id); ?>;
                                   "
                            >
                                <i class="fa fa-edit"></i> Submit</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>

    <!-- Examiner Modal-->
    <div class="modal fade" id="ExaminerModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Assign Examiner</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form method="post" action="<?php echo e(route('student')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input type="hidden" name="thesis" id="supervisor-thesis-id" value=""/>

                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-addon1">File</span>
                            </div>
                            <div class="custom-file">
                                <input type="file" style="height: 100%" class="form-control" name="file" placeholder="Your document" aria-label="file" aria-describedby="basic-addon1">
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Submit Document</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\Laravel\thesis\resources\views/student/index.blade.php ENDPATH**/ ?>