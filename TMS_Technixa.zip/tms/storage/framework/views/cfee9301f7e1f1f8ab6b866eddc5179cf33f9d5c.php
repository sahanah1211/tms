<?php $__env->startSection('content'); ?>
    <div class="card-header">
        <span>Admin home</span>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\Laravel\thesis\resources\views/admin/index.blade.php ENDPATH**/ ?>