<?php $__env->startSection('content'); ?>

    <div class="card-header">
        <span> Examiner Home </span>
        <?php if(Session::has('message')): ?>
            <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>
    </div>

    <!------- Submission ------>
    <div class="small-container mt-1">
        <div class="row">
            <table>
                <tr>
                    <th>No.</th>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Title</th>
                    <th>Actions</th>
                </tr>
            </table>
        </div>
        <div class="row pre-scrollable" style="max-height: 60vh;">
            <table>
                <?php ($count = 0); ?>
                <?php $__currentLoopData = $theses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thesis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$thesis->thesis->completed): ?>
                        <tr>
                            <td><?php echo e($count += 1); ?></td>
                            <td><?php echo e($thesis->user->key); ?></td>
                            <td>
                                <?php echo e($thesis->user->name); ?>

                            </td>
                            <td>
                                <?php echo e($thesis->thesis->title); ?>

                            </td>
                            <td>
                                <a class="btn btn-success supervisor-assign w-100" href="#"
                                   data-toggle="modal" data-target="#ExaminerModal"
                                   onclick="event.preventDefault()
                                       document.getElementById('supervisor-thesis-id').value=<?php echo e($thesis->id); ?>;
                                       "
                                >
                                    <i class="fa fa-edit"></i> Mark</a>

                                <a href="<?php echo e(route('examiner.download',$thesis->examiner->id)); ?>" class="btn btn-info w-100" ><i class="fa fa-download"></i> Download</a>
                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>

    <!-- Examiner Modal-->
    <div class="modal fade" id="ExaminerModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Mark Thesis</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form method="post" action="<?php echo e(route('examiner')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                            <input type="hidden" name="thesis" id="supervisor-thesis-id" value=""/>

                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">Mark</span>
                                </div>
                                <input type="number" class="form-control" name="mark" placeholder="Mark" aria-label="Mark" maxlength="1"   required aria-describedby="basic-addon1">
                            </div>

                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">Remark</span>
                                </div>
                                <textarea type="text" class="form-control" name="remark"  style="height: 100px;"  aria-label="Remark" aria-describedby="basic-addon1" autofocus>

                                </textarea>
                            </div>
                    </div>

                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Complete Marking</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.examiner.examiner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\tms\resources\views/examiner/index.blade.php ENDPATH**/ ?>