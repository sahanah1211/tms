

<?php $__env->startSection('content'); ?>
    <div class="modal-title">
        <h4>List of Thesis</h4>
    </div>
    <!------- Submission final ------>
    <div class="small-container mt-1">
        <div class="row">
            <table>
                <tr>
                    <th>No.</th>
                    <th>Student ID</th>
                    <th>Mark</th>
                    <th>Title</th>
                    <th>Files</th>
                </tr>
            </table>
        </div>
        <div class="row pre-scrollable" style="max-height: 60vh;">
            <table>
                <?php ($count = 0); ?>
                <?php $__currentLoopData = $theses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thesis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($count += 1); ?></td>
                        <td><?php echo e($thesis->user->key); ?></td>
                        <td>
                            <?php echo e($thesis->mark); ?>

                        </td>
                        <td>
                            <?php echo e($thesis->thesis->title); ?>

                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.thesis.delete',$thesis->id)); ?>" class="btn btn-success" style="font-size: 14px;"><i class="fa fa-delete"></i> Delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\tms\resources\views/admin/deleted.blade.php ENDPATH**/ ?>