<!DOCTYPE html>
<html>
<head>
    <title>Search Thesis</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet"
          href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
</head>
<style>
    body{
    background-color:#f8f9fc;

}
</style>
<body>

        <div class="col-md-10">
            <table class="table">
                <thead>
                <tr>
                    <th>No</th>
                    <th>Student ID</th>
                    <th>Thesis Title</th>
                    <th>Download/View</th>
                </tr>
                </thead>
                <?php if($theses): ?>
                    <tbody>
                    <?php ($count = 0); ?>
                    <?php $__currentLoopData = $theses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thesis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $thesis->thesisSubmission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($count += 1); ?>

                                </td>
                                <td>
                                    <?php echo e($sub->getUser()->key); ?>

                                </td>
                                <td>
                                    <?php echo e($thesis->title); ?>

                                </td>
                                <td>
                                    <a href="<?php echo e(route('user.download',$sub->id)); ?>" class="btn btn-success" style="font-size: 14px;"><i class="fa fa-download"></i> Download </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\projects\tms\resources\views/frontend/index.blade.php ENDPATH**/ ?>