<?php $__env->startSection('content'); ?>
    <?php if(Session::has('message')): ?>
        <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
    <?php endif; ?>
    <div class="h-75 w-50 ml-auto mr-auto">
        <div class="card text-muted bg-white mb-3">

            <form action="<?php echo e(route('admin.profile.update')); ?>" method="post" >
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <h3 class="text-center mb-1"><?php echo e($user->name); ?></h3>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="inputGroup-sizing-default">Name</span>
                        </div>
                        <input type="text" class="form-control " aria-label="Default" name="name"
                               aria-describedby="inputGroup-sizing-default" value="<?php echo e($user->name); ?>">
                    </div>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="inputGroup-sizing-default">Phone</span>
                        </div>
                        <input type="text" class="form-control " aria-label="Default" name="phone"
                               aria-describedby="inputGroup-sizing-default" value="<?php echo e($user->phone); ?>">
                    </div>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="inputGroup-sizing-default">Current Password</span>
                        </div>
                        <input type="password" class="form-control " aria-label="Default" name="c_password"
                               aria-describedby="inputGroup-sizing-default">
                    </div>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="inputGroup-sizing-default">Update Password</span>
                        </div>
                        <input type="password" class="form-control " aria-label="Default"
                               name="u_password"
                               aria-describedby="inputGroup-sizing-default">
                    </div>

                    <h6 class="card-text">Account Created : <?php echo e($user->created_at->diffForHumans()); ?></h6>
                    <h6 class="card-text">Last Updated : <?php echo e($user->updated_at->diffForHumans()); ?></h6>
                </div>

                <div class="d-flex flex-row w-100">
                    <button type="submit" class="btn text-white bg-success w-50" style="border-radius: 0">Update</button>
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <a href="#" type="button" class="btn text-white bg-dark w-50" style="border-radius: 0">Deactivate Account</a>
                    </form>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\Laravel\thesis\resources\views/admin/profile.blade.php ENDPATH**/ ?>