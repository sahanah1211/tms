<?php $__env->startSection('content'); ?>
    <div class="card-header">
        <span> Supervisor Home </span>
        <?php if(Session::has('message')): ?>
            <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>
    </div>
    <!------- Submission ------>
    <div class="small-container mt-1">
        <div class="row">
            <table>
                <tr>
                    <th>No.</th>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Title</th>
                    <th>Action</th>
                </tr>
            </table>
        </div>
        <div class="row pre-scrollable" style="max-height: 60vh;">
            <table>
                <?php ($count = 0); ?>
                <?php $__currentLoopData = $theses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thesis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($count += 1); ?></td>
                        <td><?php echo e($thesis->user->key); ?></td>
                        <td>
                            <?php echo e($thesis->user->name); ?>

                        </td>
                        <td>
                            <?php echo e($thesis->thesis->title); ?>

                        </td>
                        <td>
                            <a class="btn btn-success supervisor-assign" href="#"
                                data-toggle="modal" data-target="#SupervisorModal"
                                onclick="event.preventDefault()
                                        document.getElementById('supervisor-thesis-id').value=<?php echo e($thesis->id); ?>;
                                        "
                            >
                                Examiner
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>    
    </div>

    <!-- Supervisor Modal-->
    <div class="modal fade" id="SupervisorModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Assign Examiner</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form method="post" action="<?php echo e(route('supervisor')); ?>">
                    <?php echo csrf_field(); ?>
                <div class="modal-body">

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <label class="input-group-text" for="inputGroupSelect01">Examiners</label>
                        </div>
                        <input type="hidden" name="supervisor_thesis" id="supervisor-thesis-id" value=""/>
                        <select class="custom-select" id="inputGroupSelect01" name="examiner">
                            <?php $__currentLoopData = $examiners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $examiner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($examiner->id); ?>"><?php echo e($examiner->name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>
                </div>

                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" >Assign</button>
                </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.supervisor.supervisor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\tms\resources\views/supervisor/index.blade.php ENDPATH**/ ?>