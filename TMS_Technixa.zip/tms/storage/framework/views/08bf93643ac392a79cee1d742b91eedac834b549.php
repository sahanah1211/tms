<?php $__env->startSection('content'); ?>
    <div class="card-header">
        <span> All Thesis </span>
        <?php if(Session::has('message')): ?>
            <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>
    </div>

    <!------- Submission ------>
    <div class="small-container mt-1">
        <div class="row">
            <table>
                <tr>
                    <th>No.</th>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Title</th>
                    <th>Status</th>
                </tr>
            </table>
        </div>
        <div class="row pre-scrollable" style="max-height: 60vh;">
            <table>
                <?php ($count = 0); ?>
                <?php $__currentLoopData = $theses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thesis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($count += 1); ?></td>
                        <td><?php echo e($thesis->user->key); ?></td>
                        <td>
                            <?php echo e($thesis->user->name); ?>

                        </td>
                        <td>
                            <?php echo e($thesis->thesis->title); ?>

                        </td>
                        <td>
                            <?php if($thesis->thesis->completed): ?>
                            <a class="btn btn-success w-100" style="font-size: 14px;" href="<?php echo e(route('examiner.download',$thesis->id)); ?>"
                            >
                                <i class="fa fa-download"></i> Completed</a>
                            <?php else: ?>
                                <div class="btn btn-info w-100"> <span>OnGoing</span></div>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.examiner.examiner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\Laravel\thesis\resources\views/examiner/thesis.blade.php ENDPATH**/ ?>