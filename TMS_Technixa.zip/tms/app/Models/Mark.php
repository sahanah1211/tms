<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Mark extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable = [
        'thesis_id',
        'student_id',
        'marked_by',
        'mark',
    ];
}
