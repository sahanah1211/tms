<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class ThesisSubmission extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable=[
        'student_id',
        'thesis_id',
        'file',
        'correction'
    ];

    public function user():HasOne{
        return $this->hasOne(User::class,'id','student_id');
    }

    public function thesis():HasOne{
        return $this->hasOne(Thesis::class,'id','thesis_id');
    }
    
    public function getUser(){
        $user = User::find($this->student_id);
        return $user;
    }

    public function examiner():HasOne{
        $id = 0;
        $examinerThesis = ThesisExaminer::all()->where('thesis_id',$this->thesis_id)->where('student_id',$this->student_id)->first();
        if($examinerThesis){
            $id = $examinerThesis->id;
        }
        return $this->hasOne(ThesisExaminer::class,'id',$id);
    }
}
