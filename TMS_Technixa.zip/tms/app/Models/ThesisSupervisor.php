<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ThesisSupervisor extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable = [
        'student_id',
        'thesis_id',
        'supervisor_id',
        'created_by'
    ];

    public function user(){
        return $this->hasOne(User::class,'id','student_id');
    }

    public function thesis(){
        return $this->hasOne(Thesis::class,'id','thesis_id');
    }
}
