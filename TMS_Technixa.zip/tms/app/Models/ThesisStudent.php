<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class ThesisStudent extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable = [
        'student_id',
        'thesis_id',
        'created_by'
    ];

    public function thesis():HasOne{
        return $this->hasOne(Thesis::class,'id','thesis_id');
    }

    public function submission():HasOne{
        $id = 0;
        $sub = ThesisSubmission::all()->where('student_id',$this->student_id)
            ->where('thesis_id',$this->thesis_id)->sortByDesc('created_at')->first();
        if($sub){
            $id=$sub->id;
        }
        return $this->hasOne(ThesisSubmission::class,'id',$id);
    }

}
