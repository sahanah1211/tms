<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Thesis extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable=[
            'title',
            'description',
            'submission_date',
            'created_by',
        ];

    public function thesisSupervisor(){
        return $this->belongsTo(ThesisSupervisor::class);
    }

    public function thesisSubmission(){
        return $this->hasMany(ThesisSubmission::class,'thesis_id','id');
    }
}

