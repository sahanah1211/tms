<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /***
     * user redirection base on their role
     * @return RedirectResponse
     */
    public function index(): RedirectResponse
    {
        if (auth()->user()->role == 0){
            return redirect()->route('admin');
        }
        elseif (auth()->user()->role == 1){
            return redirect()->route('supervisor');
        }
        elseif (auth()->user()->role == 2){
            return redirect()->route('examiner');
        }
        elseif (auth()->user()->role == 3){
            return redirect()->route('student');
        }
    }
}
