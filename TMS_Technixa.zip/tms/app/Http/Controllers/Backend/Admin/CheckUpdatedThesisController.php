<?php

namespace App\Http\Controllers\Backend\Admin;

use App\Http\Controllers\Controller;
use App\Models\Thesis;
use App\Models\ThesisExaminer;
use App\Models\ThesisStudent;
use App\Models\ThesisSubmission;
use App\Models\ThesisSupervisor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;

class CheckUpdatedThesisController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(){
        $theses = ThesisSubmission::with(['user','thesis'])->get()->filter(function ($thesis){
 /* return $thesis->thesis->completed == false; */
            return $thesis->thesis;
                    })->values()->sortByDesc('created_at');
        return view('admin.updated',[
            'theses'=> $theses,
        ]);
    }

    public function thesisCompleted(){
        $theses = ThesisSubmission::with(['user','thesis'])->get()->filter(function ($thesis){
            return $thesis->thesis->completed;
        })->values()->sortByDesc('created_at');
        
        return view('admin.completed',[
            'theses'=>$theses,
        ]);
    }

    public function downloadFile($id): BinaryFileResponse
    {
        $fileUri = ThesisSubmission::find($id);
        try {
            $filePath = storage_path('app'.'\/'.$fileUri->file);
            $headers = ['Content-Type: application/pdf'];
            $fileName = null;
            Session::flash('message', "Download Successfully");
            return response()->download($filePath,$fileName,$headers);
        } catch (FileNotFoundException $e){
            Session::flash('message', "Download Fail");
            abort(403,'File not Found');
        }
}
 public function thesisDeleted(){
        $theses = ThesisSubmission::with(['user','thesis'])->get()->filter(function ($thesis){
            return $thesis->thesis;
        })->values()->sortByDesc('created_at');

        return view('admin.deleted',[
            'theses'=>$theses,
        ]);
    }

    public function deleteFile($id){
        /* $fileUri = ThesisSubmission::delete($id);
        try {
            Session::flash('message', "Delete Successfully");
            return response()->delete($filePath,$fileName,$headers);
        } catch (FileNotFoundException $e){
            Session::flash('message', "Delete Fail");
            abort(403,'File not Found');
        } */

        $delete_thesis = Thesis::find($id);
        $delete_thesis->delete();
        
        $delete_thesis = ThesisExaminer::find($id);
        $delete_thesis->delete();
    
        $delete_thesis = ThesisStudent::find($id);
        $delete_thesis->delete();

        $delete_thesis = ThesisSubmission::find($id);
        $delete_thesis->delete();

        $delete_thesis = ThesisSupervisor::find($id);
        $delete_thesis->delete();

        return redirect()->back();
    }
}