<?php

namespace App\Http\Controllers\Backend\Admin;

use App\Http\Controllers\Controller;
use App\Models\Thesis;
use App\Models\ThesisStudent;
use App\Models\ThesisSupervisor;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class ManageStudentController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(){
        $supervisors = User::all()->where('role','1');
        $theses = Thesis::all()->where('completed',false);

        return view('admin.student',[
            'supervisors'=>$supervisors,
            'theses'=>$theses,
        ]);
    }

    public function store(Request $request){
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'phone'=>['required','integer'],
            'staffId'=>['required', 'integer', 'unique:users,key'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'supervisor'=>['required'],
            'thesis'=>['required'],
        ]);

        $user = new User($request->all());
        $user->password = Hash::make($request['password']);
        $user->role=3;
        $user->key=$request->staffId;
        $user->save();

        $supervisor = new ThesisSupervisor();
        $supervisor->thesis_id = $request->thesis;
        $supervisor->supervisor_id=$request->supervisor;
        $supervisor->created_by = 2;
        $supervisor->student_id = $user->id;
        $supervisor->save();

        $student = new ThesisStudent();
        $student->thesis_id = $request->thesis;
        $student->student_id = $user->id;
        $student->created_by = 2;
        $student->save();

        Session::flash('message', "Student Successfully added");
        return redirect()->back();
    }
}
