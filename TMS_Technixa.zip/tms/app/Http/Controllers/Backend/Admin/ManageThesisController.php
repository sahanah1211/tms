<?php

namespace App\Http\Controllers\Backend\Admin;

use App\Http\Controllers\Controller;
use App\Models\Thesis;
use App\Models\ThesisExaminer;
use App\Models\ThesisSubmission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;

class ManageThesisController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(){
        return view('admin.thesis');
    }

    public function store(Request $request){

        $validated = $request->validate([
            'title' => 'required|max:255',
            'description' => 'required',
            'submission' => 'required',
            'mark' => 'required',
        ]);

        $thesis = new Thesis($request->all());
        $thesis->submission_date = $this->getFromDateAttribute($request->submission);
        $thesis->completed=false;
        $thesis->created_by=auth()->id();
        $thesis->save();

        Session::flash('message', "Thesis Successfully added");

        return redirect()->back();
    }


    public function getFromDateAttribute($value) {
        return \Carbon\Carbon::parse($value)->format('Y-m-d');
    }

    public function downloadFile($id): BinaryFileResponse
    {
        $thesis = ThesisExaminer::all()->where('id',$id)->first();

        $fileUri = ThesisSubmission::all()->where('student_id',$thesis->student_id)
            ->where('thesis_id',$thesis->thesis_id)->first();

        try {
            $filePath = storage_path('app'.'\/'.$fileUri->file);
            $headers = ['Content-Type: application/pdf'];
            $fileName = null;
            return response()->download($filePath,$fileName,$headers);
        } catch (FileNotFoundException $e){
            abort(403,'File not Found');
        }
    }

}
