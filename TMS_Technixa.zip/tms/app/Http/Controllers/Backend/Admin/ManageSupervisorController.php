<?php

namespace App\Http\Controllers\Backend\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class ManageSupervisorController extends Controller
{
    public function index(){
        return view('admin.supervisor');
    }

    public function store(Request $request){

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'phone'=>['required','numeric','digits_between:1,10'],
            'staffId'=>['required', 'numeric','digits_between:1,10', 'unique:users,key'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);

        $user = new User($request->all());
        $user->password = Hash::make($request['password']);
        $user->role=1;
        $user->key=$request->staffId;
        $user->save();

        Session::flash('message', "Supervisor Successfully added");

        return redirect()->back();
    }
}
