<?php

namespace App\Http\Controllers\Backend\Student;

use App\Http\Controllers\Controller;
use App\Models\ThesisStudent;
use App\Models\ThesisSubmission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class SubmitThesisController extends Controller
{
    public function index(){
        $userId = auth()->id();
        $theses = ThesisStudent::with(['thesis'])->get()->filter(function ($ths) use ($userId) {
            $ths->submission = ThesisSubmission::all()->where('student_id',$ths->student_id)
            ->where('thesis_id',$ths->thesis_id)->first();
            return $ths->student_id == $userId;
        })->values()->sortByDesc('created_at');
        return view('student.index',[
            'theses'=>$theses,
        ]);
    }

    public function store(Request $request){
        $thesis = ThesisStudent::find($request->thesis);
        $file = $request->file('file');
        if($file){
            $url = $file->store('public/theses');
            $filesExist = ThesisSubmission::all()->where('student_id',$thesis->student_id)->where('thesis_id',$thesis->thesis_id)->first();
            if($filesExist){
                $filesExist->file=$url;
                $filesExist->correction = 7;
                $filesExist->update();
            }
            else{
                $submit = new ThesisSubmission();
                $submit->student_id = $thesis->student_id;
                $submit->thesis_id = $thesis->thesis_id;
                $submit->file=$url;
                $submit->save();
            }
            Session::flash('message', "Updated Successfully");
        }
        else
        {
            Session::flash('message', "Please upload a file");
        }
        return redirect()->back();
    }
}
