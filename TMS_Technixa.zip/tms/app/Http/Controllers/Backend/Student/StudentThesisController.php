<?php

namespace App\Http\Controllers\Backend\Student;

use App\Http\Controllers\Controller;
use App\Models\ThesisStudent;
use App\Models\ThesisSubmission;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;

class StudentThesisController extends Controller
{
    public function index(){
        $userId = auth()->id();
        $theses = ThesisStudent::with(['thesis'])->get()->filter(function ($ths) use ($userId) {
            $ths->submission = ThesisSubmission::all()->where('student_id',$ths->student_id)
                ->where('thesis_id',$ths->thesis_id)->first();
            return $ths->student_id == $userId;
        })->values()->sortByDesc('created_at');

        return view('student.thesis',[
            'theses'=>$theses,
        ]);
    }

    public function downloadFile(Request $request): BinaryFileResponse
    {
        $fileUri = ThesisSubmission::find($request->id);
        try {
            $filePath = storage_path('app'.'\/'.$fileUri->file);
            $headers = ['Content-Type: application/pdf'];
            $fileName = null;
            return response()->download($filePath,$fileName,$headers);
        } catch (FileNotFoundException $e){
            abort(403,'File not Found');
        }
    }


}
