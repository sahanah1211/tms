<?php

namespace App\Http\Controllers\Backend\Supervisor;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SupervisorCheckController extends Controller
{
    //
}
