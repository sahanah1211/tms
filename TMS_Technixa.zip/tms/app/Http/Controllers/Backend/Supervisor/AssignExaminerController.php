<?php

namespace App\Http\Controllers\Backend\Supervisor;

use App\Http\Controllers\Controller;
use App\Models\ThesisExaminer;
use App\Models\ThesisSupervisor;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class AssignExaminerController extends Controller
{
    public function index(){
        $userId = auth()->id();
        $supTheses = ThesisSupervisor::with(['user','thesis'])->get()->filter(function ($theS) use ($userId) {
            return $theS->supervisor_id == $userId;
        })->values()->sortBy('created_at');

        $examiners = User::all()->where('role','2');

        return view('supervisor.index',[
            'examiners'=>$examiners,
            'theses'=>$supTheses,
        ]);
    }

    public  function store(Request $request){
        $userId = 3;
        $thesisSupervisor = ThesisSupervisor::find($request->supervisor_thesis);

        $thesisExaminer = new ThesisExaminer();
        $thesisExaminer->thesis_id = $thesisSupervisor->thesis_id;
        $thesisExaminer->student_id = $thesisSupervisor->student_id;
        $thesisExaminer->examiner_id = $request->examiner;
        $thesisExaminer->created_by = $userId;
        $thesisExaminer->save();

        Session::flash('message', "Examiner Successfully assign");
        return redirect()->back();
    }

    public function downloadFile($id){}


}
