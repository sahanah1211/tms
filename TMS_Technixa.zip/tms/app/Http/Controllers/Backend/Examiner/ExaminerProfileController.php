<?php

namespace App\Http\Controllers\Backend\Examiner;

use App\Http\Controllers\Controller;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class ExaminerProfileController extends Controller
{
    public function index(){
        $user = User::find(auth()->id());
        return view('examiner.profile',[
            'user'=>$user
        ]);
    }

    public function store(Request $request){

    }

    public function update(Request $request){
        $user = User::find(auth()->id());

        if ($request->c_password && $request->u_password) {
            if (Hash::check($request->c_password, $user->password)) {
                $user->fill($request->all());
                $user->password = Hash::make($request->u_password);
                $user->update();
            }
        }
        $user->fill($request->all());

        $user->update();
        Session::flash('message', "Profile Successfully Updated");
        return redirect()->back();
    }
}
