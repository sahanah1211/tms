<?php

namespace App\Http\Controllers\Backend\Examiner;

use App\Http\Controllers\Controller;
use App\Models\Mark;
use App\Models\Thesis;
use App\Models\ThesisExaminer;
use App\Models\ThesisSubmission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;


class ExaminerCheckController extends Controller
{
    public function index(){
        $userId = auth()->id();

        $theses = ThesisSubmission::with(['user','thesis'])->get()->filter(function ($theS) use ($userId) {
            $theS->examiner = ThesisExaminer::all()->where('thesis_id',$theS->thesis_id)
                ->where('student_id',$theS->student_id)->first();
            if($theS->examiner){
                return $theS->examiner->examiner_id == $userId;
            }
            return false;
        })->values()->sortBy('created_at');

        return view('examiner.index',[
            'theses'=>$theses,
        ]);
    }

    public function store(Request $request){
        $userId = auth()->id();
        $thesis = ThesisSubmission::find($request->thesis);
 /* VER Hasrul 1.0 [S] */
        if(empty($request->mark)){
            Session::flash('message', "Key-in the mark");
            return redirect()->back();
        }

        if(!intval($request->mark)){
            Session::flash('message', "Invalid mark");
            return redirect()->back();
        }

        if(intval($request->mark)<0 || intval($request->mark)>100){
            Session::flash('message', "Invalid mark");
            return redirect()->back();
        }

        /* update mark and remark concurrently */
        if($request->mark && $request->remark){

               $mark = new Mark();
               $mark->mark=$request->mark;
               $mark->marked_by=$userId;
               $mark->thesis_id = $thesis->thesis_id;
               $mark->student_id = $thesis->student_id;
               $mark->save();

            $thesis->mark = $request->mark;
            $thesis->remark = $request->remark;
            $thesis->correction = $thesis->correction + 1;
            $thesis->update();
            $thes = Thesis::find($thesis->thesis_id);
            $thes->completed = true;
            $thes->update();
            Session::flash('message', "Mark and remark has been added Successfully");

        }
        /* VER Hasrul 1.0 [E] */
        if($request->mark && !$request->remark){
               $mark = new Mark();
               $mark->mark=$request->mark;
               $mark->marked_by=$userId;
               $mark->thesis_id = $thesis->thesis_id;
               $mark->student_id = $thesis->student_id;
               $mark->save();

            $thesis->mark = $request->mark;
            $thesis->correction = $thesis->correction + 1;
            $thesis->update();

            $thes = Thesis::find($thesis->thesis_id);
            $thes->completed = true;
            $thes->update();
            Session::flash('message', "Mark has been added Successfully");
        }
        if($request->remark && !$request->mark){

            $thesis->remark = $request->remark;
            $thesis->correction = $thesis->correction + 1;
            $thesis->update();
            Session::flash('message', "Remark has been added Successfully");
        }

        return redirect()->back();
    }

    public function assigned(){
        $userId = auth()->id();

        $theses = ThesisExaminer::with(['user','thesis'])->get()->filter(function ($theS) use ($userId) {
            return $theS->examiner_id == $userId;
        })->values()->sortBy('created_at');

        return view('examiner.thesis',[
            'theses'=>$theses,
        ]);
    }

    public function downloadFile($id): BinaryFileResponse
    {
       $thesis = ThesisExaminer::all()->where('id',$id)->first();

        $fileUri = ThesisSubmission::all()->where('student_id',$thesis->student_id)
            ->where('thesis_id',$thesis->thesis_id)->first();

        try {
            $filePath = storage_path('app'.'\/'.$fileUri->file);
            $headers = ['Content-Type: application/pdf'];
            $fileName = null;
            Session::flash('message', "Download Successfully");
            return response()->download($filePath,$fileName,$headers);
        } catch (FileNotFoundException $e){
            Session::flash('message', "Download fail");
        }
    }
}
