<?php

namespace App\Http\Controllers\frontend;


use App\Http\Controllers\Controller;
use App\Models\Thesis;
use App\Models\ThesisSubmission;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;

class FrontendHomeController extends Controller
{
    public function index(){
        return view('frontend.index',[
            'theses'=>null,
        ]);
    }

    public function search(Request $request){
        $searchString = $request->search;
        $theses = Thesis::with(['thesisSubmission'])->where('title','like','%'.$searchString.'%')->get()
        ->filter(function ($ths){
            if($ths->completed){
                return true;
            }
            return false;
        })->values()->sortByDesc('updated_at');

        return view('frontend.index',[
            'theses'=>$theses
        ]);
    }

    public function downloadFile($id): BinaryFileResponse
    {
        $submission = ThesisSubmission::find($id);

        try {
            $filePath = storage_path('app'.'\/'.$submission->file);
            $headers = ['Content-Type: application/pdf'];
            $fileName = null;
            return response()->download($filePath,$fileName,$headers);
        } catch (FileNotFoundException $e){
            abort(403,'File not Found');
        }
    }

}
