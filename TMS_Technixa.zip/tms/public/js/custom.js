
$(function (){
    $('#datetimepicker1').datepicker();
});

