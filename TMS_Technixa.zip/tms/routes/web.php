<?php

use App\Http\Controllers\Backend\Admin\CheckUpdatedThesisController;
use App\Http\Controllers\Backend\Admin\DashboardController;
use App\Http\Controllers\Backend\Admin\ManageExaminerController;
use App\Http\Controllers\Backend\Admin\ManageStudentController;
use App\Http\Controllers\Backend\Admin\ManageSupervisorController;
use App\Http\Controllers\Backend\Admin\ManageThesisController;
use App\Http\Controllers\Backend\Admin\ProfileController;
use App\Http\Controllers\Backend\Examiner\ExaminerCheckController;
use App\Http\Controllers\Backend\Examiner\ExaminerProfileController;
use App\Http\Controllers\Backend\Student\StudentProfileController;
use App\Http\Controllers\Backend\Student\StudentThesisController;
use App\Http\Controllers\Backend\Student\SubmitThesisController;
use App\Http\Controllers\Backend\Supervisor\AssignExaminerController;
use App\Http\Controllers\Backend\Supervisor\SupervisorProfileController;
use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Models\User;
use App\Models\Thesis;
use App\Models\ThesisSubmission;
use App\Http\Controllers\frontend\FrontendHomeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', [HomeController::class,'index']);

Route::get('/frontend',[FrontendHomeController::class,'index']);
Route::get('/search',[FrontendHomeController::class,'search'])->name('search');
Route::get('/user/download/{id}',[FrontendHomeController::class,'downloadFile'])->name('user.download');

Auth::routes();
Route::get('/', [HomeController::class,'index']);
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/admin',[DashboardController::class,'index'])->name('admin');
Route::get('admin/student',[ManageStudentController::class,'index'])->name('admin.student');
Route::post('admin/student',[ManageStudentController::class,'store']);

Route::get('admin/supervisor',[ManageSupervisorController::class,'index'])->name('admin.supervisor');
Route::post('admin/supervisor',[ManageSupervisorController::class,'store']);

Route::get('admin/examiner',[ManageExaminerController::class,'index'])->name('admin.examiner');
Route::post('admin/examiner',[ManageExaminerController::class,'store']);

Route::get('admin/thesis',[ManageThesisController::class,'index'])->name('admin.thesis');
Route::post('admin/thesis',[ManageThesisController::class,'store']);

Route::get('admin/thesis/updated',[CheckUpdatedThesisController::class,'index'])->name('admin.thesis.updated');
Route::get('admin/thesis/deleted',[CheckUpdatedThesisController::class,'thesisDeleted'])->name('admin.thesis.deleted');
Route::get('admin/thesis/completed',[CheckUpdatedThesisController::class,'thesisCompleted'])->name('admin.thesis.completed');
Route::get('admin/thesis/download/{id}',[CheckUpdatedThesisController::class,'downloadFile'])->name('admin.thesis.download');
Route::get('admin/thesis/delete/{id}',[CheckUpdatedThesisController::class,'deleteFile'])->name('admin.thesis.delete');
Route::get('admin/profile',[ProfileController::class,'index'])->name('admin.profile');
Route::post('admin/profile',[ProfileController::class,'update'])->name('admin.profile.update');


Route::get('/examiner',[ExaminerCheckController::class,'index'])->name('examiner');
Route::post('/examiner',[ExaminerCheckController::class,'store'])->name('examiner');
Route::get('/examiner/thesis',[ExaminerCheckController::class,'assigned'])->name('examiner.thesis');
Route::get('/examiner/download/{id}',[ExaminerCheckController::class,'downloadFile'])->name('examiner.download');
Route::get('/examiner/profile',[ExaminerProfileController::class,'index'])->name('examiner.profile');
Route::post('/examiner/profile',[ExaminerProfileController::class,'update'])->name('examiner.profile.update');

Route::get('/student',[SubmitThesisController::class,'index'])->name('student');
Route::post('/student',[SubmitThesisController::class,'store']);
Route::get('student/thesis',[StudentThesisController::class,'index'])->name('student.thesis');
Route::get('student/profile',[StudentProfileController::class,'index'])->name('student.profile');
Route::post('student/profile',[StudentProfileController::class,'update'])->name('student.profile.update');

Route::get('/supervisor',[AssignExaminerController::class,'index'])->name('supervisor');
Route::post('/supervisor',[AssignExaminerController::class,'store']);
Route::get('/supervisor/download/{id}',[AssignExaminerController::class,'downloadFile'])->name('supervisor.download');
Route::get('/supervisor/profile',[SupervisorProfileController::class,'index'])->name('supervisor.profile');
Route::post('/supervisor/profile',[SupervisorProfileController::class,'update'])->name('supervisor.profile.update');

Route::post('/search',[SearchController::class,'search'])->name('search');

Auth::routes();
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
