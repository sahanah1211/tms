<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateThesisSubmissionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('thesis_submissions', function (Blueprint $table) {
            $table->id();
            $table->integer('student_id');
            $table->integer('thesis_id');
            $table->string('file');
            $table->integer('correction')->default('-1')->nullable(true);
            $table->integer('mark')->nullable(true);
            $table->text('remark')->nullable(true);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('thesis_submissions');
    }
}
